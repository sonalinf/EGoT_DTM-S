# doe-egot-gsp
Energy Grid of Things: Grid Service Provider

## Certificates and Registration
To expidite the testing phase we will use self-signed certificates generated with openssl. 