#ifndef __MOCK_GO_H__
#define __MOCK_GO_H__

class MockGO
{
public:
    MockGO();
    ~MockGO();

private:
    /* data */
};

#endif // __MOCK_GO_H__