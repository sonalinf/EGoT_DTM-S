#include <gtest/gtest.h>
#include <string>
#include <fstream>
#include <https/https_server.hpp>
#include <https/https_client.hpp>
#include <ieee-2030.5/models.hpp>
#include <xml/adapter.hpp>
#include <world/world.hpp>
#include <utilities/utilities.hpp>
#include <boost/filesystem.hpp>
#include <boost/date_time/time_zone_base.hpp>
#include <boost/date_time/local_time/local_time.hpp>
#include <boost/date_time/posix_time/posix_time.hpp> //include all types plus i/o

std::string g_program_path;


bool isClientCertification(const boost::filesystem::directory_entry &entry)
{
    std::string filename = entry.path().filename().string();
    return filename.find("client") != std::string::npos &&
           entry.path().extension() == ".crt";
}

void generateDeviceCapabilities ()
{
    sep::DeviceCapability dcap;
    dcap.poll_rate = 900;
    dcap.href = "/dcap";
    dcap.customer_account_list_link.all = 0;
    dcap.customer_account_list_link.href = "/bill";
    dcap.demand_response_program_list_link.all = 0;
    dcap.demand_response_program_list_link.href = "/dr";
    dcap.der_program_list_link.all = 0;
    dcap.der_program_list_link.href = "/derp";
    dcap.file_list_link.all = 0;
    dcap.file_list_link.href = "/file";
    dcap.messaging_program_list_link.all = 0;
    dcap.messaging_program_list_link.href = "/msg";
    dcap.prepayment_list_link.all = 0;
    dcap.prepayment_list_link.href = "/ppy";
    dcap.response_set_list_link.all = 0;
    dcap.response_set_list_link.href = "/rsps";
    dcap.tariff_profile_list_link.all = 0;
    dcap.tariff_profile_list_link.href = "/tp";
    dcap.time_link.href = "/tm";
    dcap.usage_point_list_link.all = 0;
    dcap.usage_point_list_link.href = "/upt";
    dcap.end_device_list_link.all = 0;
    dcap.end_device_list_link.href = "/edev";
    dcap.mirror_usage_point_list_link.all = 0;
    dcap.mirror_usage_point_list_link.href = "/mup";
    dcap.self_device_link.href = "/sdev";

    World* ecs = World::getInstance();
    ecs->world.entity().set<sep::DeviceCapability>(dcap);
};

void generateEndDevice(const std::string &lfdi)
{
    sep::EndDevice edev;
    edev.subscribable = sep::SubscribableType::kNone;
    edev.href = "/edev/" + lfdi;
    edev.configuration_link.href = "/cfg";
    edev.der_list_link.all = 0;
    edev.der_list_link.href = "/der";
    edev.device_category = sep::DeviceCategoryType::kSmartAppliance;
    edev.device_information_link.href = "/di";
    edev.device_status_link.href = "/ds";
    edev.file_status_link.href = "/fs";
    edev.ip_interface_list_link.all = 0;
    edev.ip_interface_list_link.href = "/ns";
    edev.lfdi = xml::util::Dehexify<boost::multiprecision::uint256_t>(lfdi);
    edev.load_shed_availability_list_link.all = 0;
    edev.load_shed_availability_list_link.href = "/lsl";
    edev.log_event_list_link.all = 0;
    edev.log_event_list_link.href = "/lel";
    edev.power_status_link.href = "/ps";
    edev.sfdi = xml::util::getSFDI(lfdi);
    edev.changed_time = psu::utilities::getTime();
    edev.enabled = true;
    edev.flow_reservation_request_list_link.all = 0;
    edev.flow_reservation_request_list_link.href = "/frq";
    edev.flow_reservation_response_list_link.all = 0;
    edev.flow_reservation_response_list_link.href = "/frp";
    edev.function_set_assignments_list_link.all = 0;
    edev.function_set_assignments_list_link.href = "/fsa";
    edev.post_rate = 900;
    edev.registration_link.href = "/rg";
    edev.subscription_list_link.all = 0;
    edev.subscription_list_link.href = "/sub";

    World* ecs = World::getInstance();
    auto e = ecs->world.entity();
    e.set<sep::EndDevice>(edev);

    AccessModule::Fingerprint fingerprint;
    fingerprint.value = lfdi;
    e.set<AccessModule::Fingerprint>(fingerprint);

    AccessModule::Subject subject;
    subject.value = lfdi;
    e.set<AccessModule::Subject>(subject);
};

void generateSelfDevice (const std::string& lfdi)
{
    sep::SelfDevice sdev;
    sdev.subscribable = sep::SubscribableType::kNone;
    sdev.href = "/sdev/" + lfdi;
    sdev.configuration_link.href = "/cfg";
    sdev.der_list_link.all = 0;
    sdev.der_list_link.href = "/der";
    sdev.device_category = sep::DeviceCategoryType::kSmartAppliance;
    sdev.device_information_link.href = "/di";
    sdev.device_status_link.href = "/ds";
    sdev.file_status_link.href = "/fs";
    sdev.ip_interface_list_link.all = 0;
    sdev.ip_interface_list_link.href = "/ns";
    sdev.lfdi = xml::util::Dehexify<boost::multiprecision::uint256_t>(lfdi);
    sdev.load_shed_availability_list_link.all = 0;
    sdev.load_shed_availability_list_link.href = "/lsl";
    sdev.log_event_list_link.all = 0;
    sdev.log_event_list_link.href = "/lel";
    sdev.power_status_link.href = "/ps";
    sdev.sfdi = xml::util::getSFDI(lfdi);

    World* ecs = World::getInstance();
    auto e = ecs->world.entity();
    e.set<sep::SelfDevice>(sdev);

    AccessModule::Fingerprint fingerprint;
    fingerprint.value = lfdi;
    e.set<AccessModule::Fingerprint>(fingerprint);

    AccessModule::Subject subject;
    subject.value = lfdi;
    e.set<AccessModule::Subject>(subject);
};

void generateRegistration(const std::string &lfdi)
{
    sep::Registration rg;
    rg.href = "/rg/" + lfdi;
    rg.poll_rate = 900;
    rg.date_time_registered = psu::utilities::getTime();
    rg.pin = xml::util::generatePIN(lfdi);

    World* ecs = World::getInstance();
    auto e = ecs->world.entity();
    e.set<sep::Registration>(rg);

    AccessModule::Fingerprint fingerprint;
    fingerprint.value = lfdi;
    e.set<AccessModule::Fingerprint>(fingerprint);

    AccessModule::Subject subject;
    subject.value = lfdi;
    e.set<AccessModule::Subject>(subject);
};

void generateTime()
{
    boost::posix_time::ptime local(boost::posix_time::second_clock::local_time());
    boost::posix_time::ptime universal(boost::posix_time::second_clock::universal_time());
    
    boost::local_time::tz_database tz_db;
    tz_db.load_from_file(g_program_path + "/timezone/date_time_zonespec.csv");
    
    boost::local_time::time_zone_ptr tz_ptr = tz_db.time_zone_from_region("America/Los_Angeles");
    boost::local_time::local_date_time ldt(local, tz_ptr);

    sep::Time tm;
    tm.poll_rate = 900;
    tm.href = "/tm";
    tm.current_time = to_time_t(universal);
    tm.dst_end_time = boost::posix_time::to_time_t(tz_ptr->dst_local_end_time(ldt.date().year()));
    tm.dst_offset = (tz_ptr->dst_offset()).total_seconds();
    tm.dst_start_time = boost::posix_time::to_time_t(tz_ptr->dst_local_start_time(ldt.date().year()));
    tm.local_time = boost::posix_time::to_time_t(local);
    tm.quality = 7; // low accuracy
    tm.tz_offset = (tz_ptr->base_utc_offset()).total_seconds();

    World* ecs = World::getInstance();
    ecs->world.entity().set<sep::Time>(tm);
};

void Initialize(const std::string &doc_root)
{
    generateDeviceCapabilities();
    generateTime();
    
    boost::filesystem::path p = doc_root + "/root-ca";
    if (boost::filesystem::exists(p)) // does path p actually exist?
    {
        if (boost::filesystem::is_directory(p)) // is path p a directory?
        {
            for (auto &entry : boost::make_iterator_range(boost::filesystem::directory_iterator(p), {}))
            {
                if (isClientCertification(entry))
                {
                    FILE *fp = fopen(entry.path().c_str(), "r");
                    X509 *cert = PEM_read_X509(fp, NULL, NULL, NULL);

                    // fingerprint
                    unsigned char md[EVP_MAX_MD_SIZE];
                    unsigned int n;
                    X509_digest(cert, EVP_sha256(), md, &n);

                    // 40 hex character length for fingerprint
                    std::ostringstream oss;
                    for (size_t i = 0; i < n; i++)
                    {
                        oss << std::hex << (int)md[i];
                    };
                    std::string lfdi = oss.str().substr(0, 40);

                    generateEndDevice(lfdi);
                    generateSelfDevice(lfdi);
                    generateRegistration(lfdi);
                    
                    X509_free(cert);
                    fclose(fp);
                }
            }
        }
        else
        {
            std::cout << p << " exists, but is not a regular file or directory\n";
        }
    }
    else
    {
        std::cout << p << " does not exist\n";
    }
};

int main(int argc, char **argv) 
{
    g_program_path = psu::utilities::getProgramPath(argv);
    Initialize(g_program_path);
    
    // run server in seperate thread and detach for auto cleanup
    HttpsServer* https_server = new HttpsServer("0.0.0.0", 8080, g_program_path);
    std::thread first(&HttpsServer::Run, https_server);
    first.detach();

    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
