# Interfaces

The base communication protocols between actors that are used by standards.

* https
* modbus
