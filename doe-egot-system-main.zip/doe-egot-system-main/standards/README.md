# Standards

A standard is an implemened interface between actors. An implemened interface applies the application layer rules for working with the data transmitted between actors. 

* IEEE 2030.5
* CTA 2045
* SunSpec Modbus
