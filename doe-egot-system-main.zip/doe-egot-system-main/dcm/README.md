# doe-egot-dcm
Energy Grid of Things: Distributed Control Module
