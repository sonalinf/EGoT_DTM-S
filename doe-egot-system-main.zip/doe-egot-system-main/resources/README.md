# Resources

These are the files required for the main builds GSP, DCM, and DTM.

* timezone : used to sync clocks between clients and servers
* sep_xml: loads the XML schema and the http WADL used within IEEE 2030.5 client/server applications
