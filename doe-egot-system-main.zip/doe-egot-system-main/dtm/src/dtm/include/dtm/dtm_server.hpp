#ifndef __DTM_SERVER_H__
#define __DTM_SERVER_H__

class DistributedTrustManagment
{
public:
    DistributedTrustManagment(int argc, char **argv);
    ~DistributedTrustManagment();
};

#endif // __DTM_SERVER_H__